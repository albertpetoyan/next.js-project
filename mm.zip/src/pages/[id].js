import React, { useEffect, useState } from "react";
import axios from "axios";
import configs from "../api";
import Wrapper from "../components/wrapper/Wrapper";
import Section_3 from "../components/section/Section_3";
import Figure_1 from "../components/figure/Figure_1";
import Button_1 from "../components/button_home_banner/Button_1";
import _ from "lodash";
import { useRouter } from "next/router";
import { routes } from "../routs";
import Section_1 from "../components/section/Section_1";

export default function SubServices(props) {
    const [data] = props.single
    useState(typeof window === "undefined");
    const router = useRouter()
    const [subServices, setSubServices] = useState([]);
    const [randomData, setRandomData] = useState([]);
    const [servicesBrandsData, setServicesBrandsData] = useState([]);
    const page = router.query.id;
    const list = [
        `Samsung ${page} repair in Fresno, CA`,
        `Electrolux ${page} repair in Fresno, CA`,
        `Amana ${page} repair in Fresno, CA`,
        `Bosch ${page} repair in Fresno, CA`,
        `LG ${page} repair in Fresno, CA`,
        `Kenmore ${page} repair in Fresno, CA`,
        `GE ${page} repair in Fresno, CA`,
        `Maytag ${page} repair in Fresno, CA`,
        `Viking ${page} repair in Fresno, CA`,
        `Whirlpool ${page} repair in Fresno, CA`,
    ];

    const getAllSubServices = async () => {
        try {
            const resp = await axios.get(
                `${configs.api}/all-services/all-services`,
                { params: { project_name: `${configs.db_name}` } }
            );
            setSubServices(resp.data);
        } catch (err) {
            console.error(err);
        }
    };

    return (
        <div className="sub_services_page">
            <div className="container">
                <Section_1
                    title={
                        data?.service_title
                            ? `${data?.service_title} Service`
                            : ""
                    }
                    text1={data?.short_description}
                    text2={data?.service_description}
                >
                    <Figure_1
                        list={list}
                        title={"Call Us for the following services:"}
                        src={`https://dappliancerepairfresno.com/images/services/${data?.service_image}`}
                        button={false}
                    />
                </Section_1>
                <Section_3 title="Call Us Today at +1 (559) 558-5348 or Schedule Service Online">
                    <div className="schedule_block">
                        <p>
                            Don’t see your appliance listed above? Don’t worry,
                            our technicians can repair more and you don’t have
                            to stay another day with a broken appliance.
                        </p>
                    </div>
                    <div className="schedule_block">
                        <Button_1
                            title="Schedule Service"
                            link={"/schedule-service"}
                        />
                    </div>
                </Section_3>
                <Section_1 title="Service Area">
                    <div className="map">
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d102252.0606436038!2d-119.86460105933945!3d36.78551291942875!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sru!2s!4v1655383543653!5m2!1sru!2s"
                            style={{ width: "100%" }}
                            allowFullScreen=""
                            loading="lazy"
                            referrerPolicy="no-referrer-when-downgrade"
                        ></iframe>
                    </div>
                </Section_1>
            </div>
        </div>
    );
}

export async function getServerSideProps({ params, query, req }) {
    if (!req) {
        return { props: null }
    }
    try {
        if (routes.includes(`/${query.id}`)) {
            const res = await axios.get(
                `${configs.api}/all-services/single-services/${query.id}`,
                { params: { project_name: `${configs.db_name}` } }
            )
            return {
                props: {
                    single: res.data.serviceData,
                },
            };
        }
    } catch (error) {
        return {
            props: {
                error: error.error,
            },
        };
    }
}
