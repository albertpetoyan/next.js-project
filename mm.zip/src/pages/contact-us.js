import React, { useState } from 'react'
import Wrapper from "../components/wrapper/Wrapper";
import Form1 from "../components/form/form_1/Form1";
import Popup1 from "../components/popups/popup_1/Popup1";
import { AiOutlineClose } from "react-icons/ai";
import { FaEnvelopeOpenText } from "react-icons/fa";
import Section_1 from "../components/section/Section_1";
import { ThreeDots } from 'react-loader-spinner'

export default function ContactUs() {
    const [modal, setModal] = useState(false)
    const [loading, setLoading] = useState(false)
    return (
        <>
            {
                modal ? <Popup1 icon={<FaEnvelopeOpenText color='#18435B' />} text='Thank you for contacting us!'
                    description='We will get in touch soon' setShow={setModal} /> : null
            }
            {
                loading ?
                    <>
                        <div className='popup_1_bg' onClick={ev => setLoading(false)} />
                        <div className="popup_1 loading" >
                            <ThreeDots color="#18435B" height={150} width={150} />
                        </div>
                    </>
                    : null
            }
                <Section_1 title={'Contact Us'}>
                    <div className="container">
                        <div className='contact_us'>
                            <Form1 setShow={setModal} load={setLoading}/>
                            <div className='map'>
                                <iframe
                                    src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d102252.0606436038!2d-119.86460105933945!3d36.78551291942875!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sru!2s!4v1655383543653!5m2!1sru!2s"
                                    style={{width: "95%"}} allowFullScreen="" loading="lazy"
                                    referrerPolicy="no-referrer-when-downgrade"></iframe>
                            </div>
                        </div>
                    </div>
                </Section_1>
        </>

    )
}
