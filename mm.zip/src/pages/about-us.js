import React, { useState, useEffect, Suspense } from "react";
import Wrapper from "../components/wrapper/Wrapper";
import Section_3 from "../components/section/Section_3";
import Figure_1 from "../components/figure/Figure_1";
import Section_1 from "../components/section/Section_1";
import Head from 'next/head'
import Figure_3 from "../components/figure/figure_3/Figure_3";


export default function AboutUs() {
    const list = [
       
    ];
    return (
        <div className="about_us">
            <Section_1 title="About Us">
                <Figure_3
                    title="We Offer Outstanding Appliance Repair Services"
                    text={`<p>We are locally owned company providing home appliance repair service in Fresno, and the surrounding areas.</p>
                            <p>If you are trying to find the best Appliance Repair service in Fresno,  or more then you are in the right place! Our technicians are specialized in repairing any kind of appliance. Instead of trying to handle the issue yourself, just give us a call or schedule service online and our experienced specialists will fix it right away.</p>`}
                    text2={`<p>Contact Us now to learn more about our services and get appliance repair help.</p>`}
                    button={false}
                />
            </Section_1>
        </div>
    );
}

