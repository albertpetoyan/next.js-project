import React, { useState, useEffect, Suspense } from "react";
import configs from "../api"
import axios from "axios";
import Wrapper from "../components/wrapper/Wrapper";
import Section_3 from "../components/section/Section_3";
import Section_1 from "../components/section/Section_1";
import Link from "next/link";


export default function AllBrands() {
    const [data, setData] = useState([]);
    useEffect(() => {
        getAllBrands();
    }, []);

    const getAllBrands = async () => {
        try {
            const resp = await axios.get(`${configs.api}/brands/brands`, {
                params: { project_name: `${configs.db_name}` },
            });
            setData(resp.data);
        } catch (err) {
            console.error(err);
        }
    };

    return (
        <div className="all-brands">
            <div className="container">
                <Section_3
                    title="Major Brands D Appliance Repair Fresno  fixes"
                    text2={
                        "Here are the most popular appliance brands our technicians repair:"
                    }
                    text3={
                        "We can proudly announce that we are able to diagnose and repair any malfunction your appliance of any brand may experience."
                    }
                />
                <Section_1>
                    <div className="all-brands-grid">
                        {data.map((number) => (
                            <div key={number.brand_id}>
                                <img
                                    src={
                                        "http://fmx-appliance-repair.com/images/brands/" +
                                        number.logo_image
                                    }
                                    style={{ width: "150px" }}
                                    alt={number.logo_title}
                                    title={number.logo_title}
                                />
                            </div>
                        ))}
                    </div>
                </Section_1>
                <Section_3 >
                    <p>
                        "Don’t see your brand listed here? Don’t worry. These are only the most repaired manufacturers. Our experienced technicians can work on any model regardless of the brand."
                    </p>
                    <p>
                        "Don’t hesitate to call <span>D Appliance Repair Fresno</span> today or <Link href="/schedule-service"><a><span >schedule your appointment</span></a></Link> online to get your appliance repaired properly and at your convenience."
                    </p>
                </Section_3>
            </div>
        </div>
    );
}

