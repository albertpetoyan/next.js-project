import React from "react";
import Section_1 from "../components/section/Section_1";
import Wrapper from "../components/wrapper/Wrapper";

export default function Page404() {
    return (
        <Section_1 title={"Page not Found"}>
            <div className="error_content">
                <div className="customParagraph contactParagraph" >
                    <h1>404</h1>
                </div>
                <div className="customParagraph contactParagraph" >
                    <div >
                        <h2>Page Not Found!</h2>
                    </div>
                    <div >
                        <p>
                            Sorry, the page you’r trying to access does not exist or
                            was moved.
                        </p>
                    </div>
                </div>
            </div>
        </Section_1>
    );
}
