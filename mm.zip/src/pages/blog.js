import React from "react";
import Head from 'next/head'
import Section_1 from "../components/section/Section_1";
import Wrapper from "../components/wrapper/Wrapper";

export default function Blog() {
    return (
        <Section_1 title={"Blog"}>
            <div className="blog_content">
                <div className="customParagraph" >
                    <h2>Comming Soon</h2>
                </div>
            </div>
        </Section_1>
    );
}
