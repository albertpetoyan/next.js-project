import React, { useEffect, useState } from "react";
import Wrapper from "../components/wrapper/Wrapper";
import Section_3 from "../components/section/Section_3";
import Form_2 from "../components/form/form_2/Form_2";
import Popup1 from "../components/popups/popup_1/Popup1";
import { FaCheckCircle, FaEnvelopeOpenText } from 'react-icons/fa';
import Section_1 from "../components/section/Section_1";
import { Audio, BallTriangle, Bars, Circles, Grid, Hearts, Oval, Puff, Rings, TailSpin , ThreeDots} from 'react-loader-spinner'

export default function ScheduleService() {
  const [modal, setModal] = useState(false)
  const [loading, setLoading] = useState(false)
  return (
    <div className="schedule_page">
      {
        modal ? <Popup1 icon={<FaCheckCircle color='#18435B' />} text='Thank You For Choosing Us!'
          description={'Your Applience Repair Service Request is successfully sent.<br/> We will get in touch soon'}
          setShow={setModal} /> : null
      }
      {
        loading ?
          <>
            <div className='popup_1_bg' onClick={ev => setLoading(false)} />
            <div className="popup_1 loading" >
              <ThreeDots color="#18435B" height={150} width={150} />
            </div>
          </>
          : null
      }
      <Section_1 title={'Service Request'}>
        <div className="container">
          <Form_2 setShow={setModal} load={setLoading} />
        </div>
      </Section_1>
      <Section_1 >
        <div className="container">
          <div className='map'>
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d102252.0606436038!2d-119.86460105933945!3d36.78551291942875!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sru!2s!4v1655383543653!5m2!1sru!2s"
              style={{ width: "95%" }} allowFullScreen="" loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"></iframe>
          </div>
        </div>
      </Section_1>
    </div>
  );
}
