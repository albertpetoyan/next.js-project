import React, { useState, useEffect } from 'react'
import Section_1 from '../components/section/Section_1'
import Figure_1 from '../components/figure/Figure_1'
import Wrapper from '../components/wrapper/Wrapper'
import ServicesSlider from '../components/services_slider/ServicesSlider'
import { useRouter } from "next/router";
import axios from "axios";
import configs from "../api";
import Head from 'next/head'
import List_1 from '../components/list/list_1/List_1'


export default function home() {

    const router = useRouter()
    const [data, setData] = useState([]);
    const [brands, setBrands] = useState([]);


    useEffect(() => {
        getAllServices();
        getBrands();
    }, []);

    const getAllServices = async () => {
        try {
            const resp = await axios.get(
                `${configs.api}/all-services/top-services-fresno`,
                { params: { project_name: `${configs.db_name}` } }
            );

            setData(resp.data);
        } catch (err) {
            console.error(err);
        }
    };
    const getBrands = async () => {
        try {
            const resp = await axios.get(`${configs.api}/brands/brands`, {
                params: { project_name: `${configs.db_name}` },
            });
            setBrands(resp.data);
        } catch (err) {
            console.error(err);
        }
    };
    return (
        <div className="home_page">
            <Section_1>
                <Figure_1
                    title="Who We Are"
                    button={false}
                />
            </Section_1>
            <Section_1 title={"Appliance Repair Services We Provide"}>
                <div className="container">
                    <ServicesSlider data={data} />
                </div>
            </Section_1>
            <Section_1 title={"Why appliance repair fresno ?"}>
                <div className="container">
                    <List_1 />
                </div>
            </Section_1>
            <div className="intro">
                <Section_1 >
                    <div className="container">
                        <h3>Up 5 year warranty for all replaced parts</h3>
                    </div>
                </Section_1>
            </div>
        </div>
    )
}

