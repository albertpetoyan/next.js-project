import { useRouter } from 'next/router'
import { useEffect } from 'react'
import "react-loader-spinner/dist/loader/css/react-spinner-loader.css";
import { Audio,BallTriangle ,Bars,Circles,Grid,Hearts,Oval,Puff,Rings,TailSpin} from 'react-loader-spinner'


export default function index() {
  const router = useRouter()
  useEffect(() => {
    router.push('/home', undefined,{ shallow: true })
  }, [])
  return (
    <div style={{display:'flex', justifyContent: 'center', alignItems: 'center', height:'100vh', width:'100vw'}}>
      <Audio color="#ac1125" height={150} width={150} />
    </div>
  )
}
