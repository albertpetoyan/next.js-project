import React, { useState, useEffect, Suspense } from "react";
import configs from "../api";
import axios from "axios";
import Wrapper from "../components/wrapper/Wrapper";
import Section_3 from "../components/section/Section_3";
import Card_4 from "../components/card/card_4/Card_4";
import Button_1 from "../components/button_home_banner/Button_1";
import Section_1 from "../components/section/Section_1";
import Figure_2 from "../components/figure/figure_2/Figure_2";

export default function Services({ allservices }) {
    const [data, setData] = useState([]);
    useEffect(() => {
        getAllServices();
    }, []);

    const getAllServices = async () => {
        try {
            const resp = await axios.get(
                `${configs.api}/all-services/all-services`,
                { params: { project_name: `${configs.db_name}` } }
            );
            setData(resp.data);
        } catch (err) {
            console.error(err);
        }
    };
    return (
        <div className="services_page">
            <Section_1
                title="Experienced Staff of Appliance Repair Frenso"
            >
                <Figure_2
                    button={false}
                />
            </Section_1>
            <Section_1
                title="Appliance services"
            >
                <div className="container">
                    <div className="service_item_block">
                        {data.map((service) => (
                            <div className="service_item" key={service.service_id}>
                                <Card_4
                                    key={service.service_id}
                                    service={service}
                                />
                            </div>
                        ))}
                    </div>
                </div>
            </Section_1>
        </div>
    );
}

// Services.getInitialProps = async ({ query }) => {
//     const res = await axios.get(
//         `${url.url}/all-services/all-services`,
//         { params: { project_name: `${configs.db_name}` } })
//     const allservices = res.data
//     return { allservices }
// }