import "../styles/_tools.scss"
import "../styles/_fonts.scss"
import "../styles/_var.scss"
import "../components/banner_home/_banner_2.scss";
import "../components/figure/figure_3/figure_3.scss";
import "../components/banner_home_2/banner_1.scss";
import "../components/brands_slider/brands.scss"
import "../components/button_home_banner/button_1.scss"
import "../components/card/card_5/card_5.scss"
import "../components/footer/footer_2/footer_2.scss";
import "../components/form/form_1/form_1.scss"
import "../components/form/form_2/form_2.scss"
import "../components/header_menu/header_menu_4.scss";
import '../components/header_menu/header_top_info_2/styles/header_info_2.scss'
import "../components/popups/popup_1/popup_1.scss"
import "../components/section/section_1.scss"
import "../components/section/section_3.scss"
import '../components/services_slider/servicesSlider.scss'
import "../components/wrapper/wrapper.scss";
import '../components/figure/figure_1.scss'
import '../components/figure/figure_2/figure_2.scss'
import "../components/list/list_1/list_1.scss"
import "../components/card/card_4/card_4.scss";
import "../styles/pages/about_us.scss"
import "../styles/pages/all_brands.scss"
import "../styles/pages/contact_us.scss"
import "../styles/pages/services.scss"
import "../styles/pages/scheduleService.scss"
import "../styles/pages/404_page.scss"
import "../styles/pages/sub_services.scss"
import "../styles/pages/home.scss"
import "../styles/pages/blog.scss"
import '../styles/pages/404_page.scss'
import "../styles/nprogress.scss"
import axios from "axios";
import configs from "../api";
import Head from 'next/head'
import Wrapper from "../components/wrapper/Wrapper";

export default function App({ Component, meta_info, pageProps }) {
    return (
        <Wrapper>
            <Head>
                <title>{meta_info[0]?.page_title} - D Appliance Repair | +1 (559) 558-5348</title>
                <meta property="og:title" content={` - D Appliance Repair | +1 (559) 558-5348`} key="title" />
                <meta name="title" content={`${meta_info[0]?.page_title} - D Appliance Repair | +1 (559) 558-5348`} key="title" />
                <link rel="preconnect" href="https://fonts.googleapis.com" />
                <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
                <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet" />
            </Head>
            <Component
                {...pageProps}
                {...meta_info}
            />
        </Wrapper>
    )
}

App.getInitialProps = async ({ ctx }) => {
    let page = ctx.asPath.replace("/", "")
    let meta_info
    const resp = await axios.get(
        `${configs.api}/meta`,
        {
            params: {
                project_name: `${configs.db_name}`,
                page
            }
        }
    );
    meta_info = resp.data
    return { meta_info }
}
