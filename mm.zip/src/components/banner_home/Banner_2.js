import React from "react";
import Button_1 from "../button_home_banner/Button_1";

export default function Banner_2() {
    return (
        <div className="banner_2_block" >
            <div className="container">
                <div className="banner_2_content_block">
                    <div className="banner_2_title_block">
                        <h1>
                            Appliance Repair <br />
                            Service Fresno
                        </h1>
                        <h2>Fast & On Time Appliance Repair Service</h2>
                    </div>
                    <div className="banner_2_btn_block">
                        <Button_1 title='Schedule Service' link={'/schedule-service'} />
                        <Button_1 title='Learn More' link={'/schedule-service'} />
                    </div>
                </div>
            </div>
        </div>
    );
}
