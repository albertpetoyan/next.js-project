import React, { useEffect, useState } from "react";
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";
import { MdArrowForwardIos, MdArrowBackIosNew } from "react-icons/md";
import Slider from "react-slick";
import axios from "axios";
import url from "../../api";

export default function Brands() {
    const settings = {
        infinite: true,
        autoplay: true,
        speed: 500,
        slidesToShow: 6,
        slidesToScroll: 1,
        initialSlide: 0,
        dots: false,
        nextArrow: <MdArrowForwardIos />,
        prevArrow: <MdArrowBackIosNew />,
        responsive: [
            {
                breakpoint: 1320,
                settings: {
                    slidesToShow: 6,
                    slidesToScroll: 3,
                    infinite: true,
                    dots: false
                }
            },
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                    infinite: true,
                    dots: false
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 2,
                    initialSlide: 2
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    };

    const [brands, setBrands] = useState([]);
    useEffect(() => {
        getBrands();
    }, []);

    const getBrands = async () => {
        try {
            const resp = await axios.get(`${url.url}/brands/brands`, {
                params: { project_name: "applljxg_fresno" },
            });
            setBrands(resp.data);
        } catch (err) {
            console.error(err);
        }
    };

    return (
       <div className="brands_slider">
            <Slider
                {...settings}
                className="carousel"
            >
                {brands.map((brand) => (
                    <div key={brand.brand_id} className='brand_block'>
                        <img
                            style={{ width: "150px" }}
                            src={
                                "https://dappliancerepairfresno.com/images/brands/" +
                                brand.logo_image
                            }
                            alt={brand.logo_title}
                            title={brand.logo_title}
                        />
                    </div>
                ))}
            </Slider>
       </div>
    );
}
