import React, { useState } from 'react'
import Link from 'next/link';
import { AiFillCaretDown } from 'react-icons/ai'
import Image from 'next/image'
import logo from '../../../logo/logo.svg'

export default function HeaderInfo2({ scroll }) {
    const [burger, setBurger] = useState(false)
    const [showServices, setShowServices] = useState(false)

    return (
        <>
            <div className='header-info-2'>
                <div className='container'>
                    <div className='row header-info-row'>
                        <div className='header-4-logo'>

                        <Link href="/home">
                                <a>
                                    <Image
                                        src={logo}
                                        alt="photo"
                                    />
                                </a>

                        </Link>
                        </div>

                        <div className='header-info-block'>
                            <p className='header-phone'>
                                <a href="tel:+1 (559) 777-5080">+1 (559) 777-5080</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
