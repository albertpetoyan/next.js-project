import React, { useEffect, useRef, useState } from 'react'
import Link from 'next/link';
import { AiFillCaretDown } from 'react-icons/ai'
import HeaderInfo2 from "./header_top_info_2/HeaderInfo2";
import logo, { ReactComponent as Logo } from '../../logo/logo.svg'
import { useRouter } from "next/router";
import Image from "next/image";
import { FiChevronDown } from 'react-icons/fi'
import Button_1 from '../button_home_banner/Button_1';

export default function HeaderMenu4() {
    const navlinks = [
        { title: 'Home', path: '/home' },
        { title: 'Services', path: '/services' },
        { title: 'About Us', path: '/about-us' },
        { title: 'Blog', path: '/blog' },
        { title: 'Contact Us', path: '/contact-us' },
    ]

    const navServiceLinks = [
        { title: 'Refrigerator Repair', path: '/refrigerator-repair' },
        { title: 'Freezer Repair', path: '/freezer-repair' },
        { title: 'Wine cooller Repair', path: '/wine-cooler-repair' },
        { title: 'Washing Machine Repair', path: '/washing-machine-repair' },
        { title: 'Dryer Repair', path: '/dryer-repair' },
        { title: 'Dishwasher Repair', path: '/dishwasher-repair' },
        { title: 'Stove Repair', path: '/stove-repair' },
        { title: 'Oven Repair', path: '/oven-repair' },
        { title: 'Range hood Repair', path: '/range-hood-repair' },
        { title: 'Microwave Repair', path: '/microwave-repair' },
        { title: 'Garbage disposal Repair', path: '/garbage-disposal-repair' },
        { title: 'Coffee system Repair', path: '/coffee-system-repair' },
    ]

    const [burger, setBurger] = useState(false)
    const [showServices, setShowServices] = useState(false)
    const router = useRouter()
    useEffect(() => {
        if (burger) {
            const tag = document.getElementsByTagName('body')
            tag[0].style.overflowY = 'hidden'
        } else {
            const tag = document.getElementsByTagName('body')
            tag[0].style.overflowY = 'scroll'
        }
    }, [burger])

    useEffect(()=> {
        global.window.addEventListener("click", function (event) {
            setShowServices(false)
        });
    })


    const handleDropDown = (ev) => {
        if (ev.target.id === 'Services') {
            setShowServices(true)
        }
    }

    const handleCloseDropDown = (ev) => {
        const id = navServiceLinks.find(t => t.title === ev.target.id)
        if (!id) {
            setShowServices(false)
        }
    }

    return (
        <>
            <HeaderInfo2 />
            <div className='header-4'>
                <div className='container'>
                    <div className='row header-4-row'>
                        <div className='header-4-logo'>
                            <Link href="/home">
                                <a>
                                    <Image
                                        src={logo}
                                        alt="photo"
                                    />
                                </a>

                            </Link>
                        </div>
                        <div className='nav'>
                            <ul className='nav-links'>
                                {navlinks.map(link => (
                                    <li key={link.title} id={link.title} >
                                        <Link href={link.path}>
                                            <a
                                                id={link.title}
                                                onMouseEnter={handleDropDown}
                                                onMouseLeave={handleCloseDropDown}
                                                className={link.path === router.pathname ? 'active' : `nav-link-${link.title}`}
                                            >
                                                {link.title}
                                                <span id={link.title}>
                                                    {link.title === 'Services' &&
                                                        <FiChevronDown />}
                                                </span>
                                            </a>
                                        </Link>
                                    </li>
                                ))}
                            </ul>
                        </div>
                        <div className={showServices ? 'service_links active' : 'service_links'}>
                            <div id={'Services'} className='service_links_drop_down_bg' onMouseEnter={handleDropDown} onMouseLeave={handleCloseDropDown}>
                                <ul>
                                    {navServiceLinks.map(link => (
                                        <li id={link.title} key={link.title}>
                                            <Link href={link.path}>
                                                <a className={link.path === router.asPath ? 'active' : ''}>
                                                    {link.title}
                                                </a>
                                            </Link>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        </div>
                        <div onClick={ev => setBurger(false)}
                            className={burger ? 'header-burger-backGround active' : 'header-burger-backGround'} />
                        <div id='burger' className={burger ? 'nav-burger open-burger' : 'nav-burger'}>
                            <div className='burger' onClick={ev => setBurger(!burger)}>
                                <span className='burger-list' />
                                <span className='burger-list' />
                                <span className='burger-list' />
                            </div>
                        </div>
                        <div id='burger' onClick={ev => setBurger(false)} className='nav-burger-links'>
                            <ul className='nav-links'>
                                <li><Link href="/home">Home</Link></li>
                                <li><Link href="/about-us">About Us</Link></li>
                                <li>
                                    <div id='header-services' onClick={ev => {
                                        router('/services')
                                    }}>Services<span
                                        className='header-burger-services-arrow'
                                        onClick={ev => {
                                            ev.stopPropagation()
                                            setShowServices(!showServices)
                                        }
                                        } id='service'>
                                            <AiFillCaretDown
                                                id='service'
                                                fontSize={15} />
                                        </span></div>
                                    {showServices && burger ?
                                        <div className='mobile-header-service-items'>
                                            <ul onClick={ev => setBurger(false)} className='services-item-links'>
                                                {navServiceLinks.map(link => (
                                                    <li key={link.title}><Link
                                                        href={link.path}><a>{link.title}</a></Link></li>
                                                ))}
                                            </ul>
                                        </div>
                                        : null}
                                </li>
                                <li><Link href="/brands">Brands</Link></li>
                                <li><Link href="/contact-us">Contact Us</Link></li>
                            </ul>
                        </div>
                        <div className='header-button'>
                            <Button_1 link={'/schedule-service'} title={'Schedule Service'} />
                        </div>
                    </div>
                </div>
            </div>

        </>
    )
}
