import React from "react";
import configs from "../../../api";

export default function Card_4({ service }) {
    return (
        <div className="card_4" style={{
            backgroundImage: `url(${configs.url}/images/services/${service.service_image})`
        }}>
            <div className="content">
                <h2 className="title">{service.service_title}</h2>
                <p className="copy">Check out all of these gorgeous mountain </p>
                <button className="btn">Learn More</button>
            </div>
        </div>
    );
}
