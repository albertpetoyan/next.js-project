import React from "react";
import Link from "next/link";
import { useRouter } from "next/router";

export default function Card_5({ service }) {
    const router = useRouter()
    const handleServices = () => {
        router.push(`/${service.service_link}`)
    }
    return (
        <div className="card_5" onClick={handleServices}>
            <div className="card_5_photo_block">
                <img className="card_5_img" src={"https://dappliancerepairfresno.com/images/services/" + service.service_image} alt="" />
            </div>
            <div className="card_5_title_block">
                <h4>{service.service_title}</h4>
            </div>
        </div>
    );
}
