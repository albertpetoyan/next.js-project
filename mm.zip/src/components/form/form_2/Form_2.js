import React, { useEffect, useState, useRef } from "react";
import axios from "axios";
import configs from "../../../api";
import validation from "../../../tools/validation";
import _ from "lodash";
import Link from "next/link";
import Button_1 from "../../button_home_banner/Button_1";

export default function Form_2({ setShow, load }) {
    const [errors, setErrors] = useState({});
    const [form, setForm] = useState({
        first_name: "",
        last_name: "",
        email: "",
        phone_number: "",
        states: "",
        city: "",
        address: "",
        zip_code: "",
        appliance: "",
        brand: "",
        service_date: "",
        service_time: "",
        description: "",
    });
    const [data, setData] = useState(null);
    const [states, setStates] = useState(null);
    const [cities, setCities] = useState(null);

    useEffect(() => {
        getAllServices();
        getAllCity(3924);
    }, []);

    const getAllServices = async () => {
        try {
            const resp = await axios.get(
                `${configs.api}/contact-us-fresno/selects`,
                { params: { project_name: `${configs.db_name}` } }
            );
            setData(resp.data);
        } catch (err) {
            console.error(err);
        }
    };

    const handleChange = (e) => {
        setForm((prevState) => ({
            ...prevState,
            [e.target.name]: e.target.value,
        }));

        const val = validation[e.target.name](e.target.value);
        if (val?.status !== "ok") {
            setErrors({ ...errors, [e.target.name]: val.errors });
        } else {
            setErrors({ ...errors, [e.target.name]: "" });
        }

        if (e.target.name == "country") {
            getAllStates(3924);
            setCities(null);
        }
        if (e.target.name == "state") {
            getAllCity(e.target.value);
        }
    };

    const getAllStates = async (id) => {
        try {
            const resp = await axios.post(
                `${configs.api}/country_state_city/states/` + id,
                { params: { project_name: `${configs.db_name}` } }
            );
            setStates(resp.data);
        } catch (err) {
            console.error(err);
        }
    };
    const getAllCity = async (id) => {
        try {
            const resp = await axios.post(
                `${configs.api}/country_state_city/city/` + id,
                { params: { project_name: `${configs.db_name}` } }
            );
            setCities(resp.data);
        } catch (err) {
            console.error(err);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        let err = {};
        for (const i in form) {
            if (validation[i]) {
                const v = validation[i](form[i]);
                err[i] = v.errors;
                if (v.status !== "ok") {
                    _.set(errors, i, v.errors);
                    setErrors({ ...errors });
                } else {
                    delete err[i];
                }
            }
        }
        console.log(err);

        if (!_.isEmpty(err)) {
            return;
        }
        load(true)
        try {
            const resp = await axios.post(
                `${configs.api}/contact-us-services-fresno/schedule`,
                { check: form },
                { params: { project_name: `${configs.db_name}` } }
            );
            if (resp.status == 200) {
                load(false)
                setShow(true)
                setForm({
                    first_name: "",
                    last_name: "",
                    email: "",
                    phone_number: "",
                    states: "",
                    city: "",
                    address: "",
                    zip_code: "",
                    appliance: "",
                    brand: "",
                    service_date: "",
                    service_time: "",
                    description: "",
                })
            }
        } catch (err) {
            console.error(err);
        }
    };

    return (
        <form className="form">
            <div className="form_block">
                <h4>Personal Details</h4>
                <div className="form_row">
                    <div className="input_block">
                        <label for="first_name">
                            Your First Name{" "}
                            <span style={{ color: "red" }}>*</span>
                        </label>
                        <input style={errors.first_name ? { border: '1px solid #AC1125' } : { border: '1px solid #B0B2B5' }}
                            id="first_name"
                            className="inputEl"
                            type="text"
                            pattern="[^-][a-zA-Z -]{2,100}"
                            name="first_name"
                            value={form.first_name}
                            onChange={(e) => handleChange(e)}
                        />
                        <small>{errors.first_name}</small>
                    </div>
                    <div className="input_block">
                        <label for="last_name">
                            Your Last Name{" "}
                            <span style={{ color: "red" }}>*</span>
                        </label>
                        <input style={errors.last_name ? { border: '1px solid #AC1125' } : { border: '1px solid #B0B2B5' }}
                            value={form.last_name}
                            id="last_name"
                            className="inputEl"
                            type="text"
                            pattern="[^-][a-zA-Z -]{2,100}"
                            name="last_name"
                            onChange={(e) => handleChange(e)}
                        />
                        <small>{errors.last_name}</small>
                    </div>
                    <div className="input_block">
                        <label for="email">
                            Email <span style={{ color: "red" }}>*</span>
                        </label>
                        <input style={errors.email ? { border: '1px solid #AC1125' } : { border: '1px solid #B0B2B5' }}
                            value={form.email}
                            id="email"
                            className="inputEl"
                            type="text"
                            placeholder="example@example.com"
                            pattern="^[a-zA-Z0-9_\.\-]+@[a-zA-Z0-9\.-]+$"
                            name="email"
                            onChange={(e) => handleChange(e)}
                        />
                        <small>{errors.email}</small>
                    </div>
                    <div className="input_block">
                        <label for="phone_number">
                            Phone Number <span style={{ color: "red" }}>*</span>
                        </label>
                        <input style={errors.phone_number ? { border: '1px solid #AC1125' } : { border: '1px solid #B0B2B5' }}
                            value={form.phone_number}
                            id="phone_number"
                            className="inputEl"
                            type="text"
                            pattern="\+?[()0-9- ]{4,25}"
                            name="phone_number"
                            onChange={(e) => handleChange(e)}
                        />
                        <small>{errors.phone_number}</small>
                    </div>
                </div>
                <h4>Location Details</h4>
                <div className="form_row">
                    <div className="input_block">
                        <label for="country">
                            Country
                        </label>
                        <input
                            id="country"
                            className="inputEl"
                            type="text"
                            pattern="[a-zA-Z0-9 \.,()]{2,100}"
                            name="country"
                            onChange={(e) => handleChange(e)}
                            disabled
                            defaultValue="United States"
                        />
                    </div>
                    <div className="input_block">
                        <label for="states">
                            State
                        </label>
                        <input
                            id="states"
                            className="inputEl"
                            type="text"
                            pattern="[a-zA-Z0-9 \.,()]{2,100}"
                            name="states"
                            onChange={(e) => handleChange(e)}
                            disabled
                            defaultValue="California"
                        />
                    </div>
                    <div className="input_block">
                        <label for="city">
                            City <span style={{ color: "red" }}>*</span>
                        </label>
                        <select style={errors.city ? { border: '1px solid #AC1125' } : { border: '1px solid #B0B2B5' }}
                            value={form.city}
                            id="city"
                            className="inputEl"
                            onChange={(e) => handleChange(e)}
                            name="city"
                            data-key="cities"
                            required
                        >
                            <option value=''>-- Select a City--</option>
                            {cities
                                ? cities?.city.map((item) => {
                                    return (
                                        <option
                                            key={item.id}
                                            value={item.name}
                                        >
                                            {item.name}
                                        </option>
                                    );
                                })
                                : null}
                        </select>
                        <small>{errors.city}</small>
                    </div>
                    <div className="input_block">
                        <label for="address">
                            Address <span style={{ color: "red" }}>*</span>
                        </label>
                        <input style={errors.address ? { border: '1px solid #AC1125' } : { border: '1px solid #B0B2B5' }}
                            value={form.address}
                            id="address"
                            className="inputEl"
                            required
                            type="text"
                            name="address"
                            onChange={(e) => handleChange(e)}
                        />
                        <small>{errors.address}</small>
                    </div>
                    <div className="input_block">
                        <label for="zip_code">
                            Zip Code <span style={{ color: "red" }}>*</span>{" "}
                        </label>
                        <input style={errors.zip_code ? { border: '1px solid #AC1125' } : { border: '1px solid #B0B2B5' }}
                            value={form.zip_code}
                            id="zip_code"
                            className="inputEl"
                            required
                            type="text"
                            pattern="[0-9]{1,10}"
                            name="zip_code"
                            onChange={(e) => handleChange(e)}
                        />
                        <small>{errors.zip_code}</small>
                    </div>
                </div>
                <h4>Service Details</h4>
                <div className="form_row">
                    <div className="input_block">
                        <label for="appliance">
                            Appliance <span style={{ color: "red" }}>*</span>
                        </label>
                        <select style={errors.appliance ? { border: '1px solid #AC1125' } : { border: '1px solid #B0B2B5' }}
                            value={form.appliance}
                            id="appliance"
                            className="inputEl"
                            onChange={(e) => handleChange(e)}
                            name="appliance"
                            data-key="appliances"
                            required
                        >
                            <option value=''>-- Select a Appliance --</option>
                            {data
                                ? data?.select1.map((item) => {
                                    return (
                                        <option
                                            key={item.appliance_id}
                                            value={item.appliance_name}
                                        >
                                            {item.appliance_name}
                                        </option>
                                    );
                                })
                                : null}
                            <option value="99">Other</option>
                        </select>
                        <small>{errors.appliance}</small>
                    </div>
                    <div className="input_block">
                        <label for="brand">
                            Brand <span style={{ color: "red" }}>*</span>
                        </label>
                        <select style={errors.brand ? { border: '1px solid #AC1125' } : { border: '1px solid #B0B2B5' }}
                            value={form.brand}
                            id="brand"
                            className="inputEl"
                            onChange={(e) => handleChange(e)}
                            name="brand"
                            data-key="brands"
                            required
                        >
                            <option value=''>-- Select a Brand --</option>
                            {data
                                ? data?.select.map((item) => {
                                    return (
                                        <option
                                            key={item.brand_id}
                                            value={item.brand_name}
                                        >
                                            {item.brand_name}
                                        </option>
                                    );
                                })
                                : null}
                            <option value="99">Other</option>
                        </select>
                        <small>{errors.brand}</small>
                    </div>
                    <div className="input_block">
                        <label for="service_date">
                            Service Date <span style={{ color: "red" }}>*</span>
                        </label>
                        <input style={errors.service_date ? { border: '1px solid #AC1125' } : { border: '1px solid #B0B2B5' }}
                            value={form.service_date}
                            id="service_date"
                            className="inputEl"
                            required
                            type="date"
                            name="service_date"
                            min={new Date().toISOString().split("T")[0]}
                            onChange={(e) => handleChange(e)}
                        />
                        <small>{errors.service_date}</small>
                    </div>
                    <div className="input_block">
                        <label for="service_time">
                            Service Time <span style={{ color: "red" }}>*</span>
                        </label>
                        <input style={errors.service_time ? { border: '1px solid #AC1125' } : { border: '1px solid #B0B2B5' }}
                            value={form.service_time}
                            id="service_time"
                            className="inputEl"
                            required
                            type="time"
                            name="service_time"
                            onChange={(e) => handleChange(e)}
                        />
                        <small>{errors.service_time}</small>
                    </div>
                </div>
                <div className="form_row">
                    <div className="input_block">
                        <label for="description">
                            Brief Description of Issue{" "}
                            <span style={{ color: "red" }}>*</span>
                        </label>
                        <textarea style={errors.description ? { border: '1px solid #AC1125' } : { border: '1px solid #B0B2B5' }}
                            value={form.description}
                            id="description"
                            className="inputEl"
                            as="textarea"
                            onChange={(e) => handleChange(e)}
                            name="description"
                            pattern="[^<]([^>]+)?[^>]"
                            rows={4}
                            required
                        ></textarea>
                        <small>{errors.description}</small>
                    </div>
                </div>
                <div className="form_btn_group">
                    <div
                        className="button_1_block"
                        onClick={(e) => handleSubmit(e)}
                    >
                        <Button_1 title={"Schedule Service"} />
                    </div>
                </div>
            </div>
        </form>
    );
}
