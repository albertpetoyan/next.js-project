import React, {useCallback, useState} from 'react';
import _ from 'lodash'
import configs from "../../../api";
import Section_3 from "../../section/Section_3";
import validation from "../../../tools/validation";
import axios from "axios";
import Button_1 from "../../button_home_banner/Button_1";

function Form1({setShow, load}) {
    const [errors, setErrors] = useState({})
    const [formData, setFormData] = useState({
        first_name: '',
        last_name: '',
        email: '',
        phone_number: '',
        description: '',
    })

    const handleChange = (ev) => {
        setFormData(prevState => ({...prevState, [ev.target.name]: ev.target.value}))
        const val = validation[ev.target.name](ev.target.value)
        if (val?.status !== 'ok') {
            setErrors({...errors, [ev.target.name]: val.errors})
        } else {
            setErrors({...errors, [ev.target.name]: ''})
        }
    }

    const handleSubmit = async (ev) => {
        ev.preventDefault()
        let err = {};
        for (const i in formData) {
            if (validation[i]) {
                const v = validation[i](formData[i])
                err[i] = v.errors
                if (v.status !== 'ok') {
                    _.set(errors, i, v.errors)
                    setErrors({...errors})
                } else {
                    delete err[i]
                }
            }
        }

        if (!_.isEmpty(err)) {
            return;
        }
        load(true)
        try {
            const resp = await axios.post(`${configs.api}/contact-us-services-fresno/contactUs`, {check: formData}, {params: {project_name: "applljxg_d_appliance"}});
            console.log(resp)
            if (resp.status == 200) {
                load(false)
                setShow(true)
                setFormData({
                    first_name: '',
                    last_name: '',
                    email: '',
                    phone_number: '',
                    description: '',
                });
            }
        } catch (e) {
            console.log(e)
        }

    }

    return (
        <div className='form_1_div'>
            <form className='form_1' onSubmit={handleSubmit}>
                <div className='form_row'>
                    <div className='form_column'>
                        <label className='form_label required' htmlFor="first_name">First Name</label>
                        <input style={errors.first_name ? {border: '1px solid #AC1125'} : {border: '1px solid #B0B2B5'}}
                               value={formData.first_name}
                               id='first_name' name='first_name'
                               type='text'
                               onChange={ev => handleChange(ev)}/>
                        <samll className='error_massage'
                               style={errors.first_name ? {visibility: 'visible', opacity: 1} : {
                                   visibility: 'hidden',
                                   opacity: 0
                               }}>{errors.first_name}</samll>
                    </div>
                    <div className='form_column'>
                        <label className='form_label required' htmlFor="last_name">Last Name</label>
                        <input style={errors.last_name ? {border: '1px solid #AC1125'} : {border: '1px solid #B0B2B5'}}
                            value={formData.last_name} id='last_name' name='last_name' type='text'
                            onChange={ev => handleChange(ev)}/>
                        <small className='error_massage'
                               style={errors.last_name ? {visibility: 'visible', opacity: 1} : {
                                   visibility: 'hidden',
                                   opacity: 0
                               }}>{errors.last_name}</small>
                    </div>
                </div>
                <div className='form_row'>
                    <div className='form_column'>
                        <label className='form_label required' htmlFor="email">Email</label>
                        <input  style={errors.email ? {border: '1px solid #AC1125'} : {border: '1px solid #B0B2B5'}}
                            value={formData.email} id='email' name='email' type='text'
                               onChange={ev => handleChange(ev)}/>
                        <small className='error_massage'
                               style={errors.email ? {visibility: 'visible', opacity: 1} : {
                                   visibility: 'hidden',
                                   opacity: 0
                               }}>{errors.email}</small>
                    </div>
                    <div className='form_column'>
                        <label className='form_label required' htmlFor="phone_number">Phone Number</label>
                        <input style={errors.phone_number ? {border: '1px solid #AC1125'} : {border: '1px solid #B0B2B5'}}
                            value={formData.phone_number} id='phone_number' name='phone_number' type='text'
                               onChange={ev => handleChange(ev)}/>
                        <small className='error_massage'>{errors.phone_number}</small>
                    </div>
                </div>
                <div className='form_textarea_row'>
                    <div className='form_column'>
                        <label className='form_label required' htmlFor="message">Your Message</label>
                        <textarea style={errors.description ? {border: '1px solid #AC1125'} : {border: '1px solid #B0B2B5'}}
                            value={formData.description} rows='5' name='description' id='message'
                                  onChange={ev => handleChange(ev)}/>
                        <small className='error_massage'
                               style={errors.description ? {visibility: 'visible', opacity: 1} : {
                                   visibility: 'hidden',
                                   opacity: 0
                               }}>
                            {errors.description}
                        </small>
                    </div>
                </div>
                <div className="form_btn_group">
                    <div
                        className="button_1_block"
                        onClick={(e) => handleSubmit(e)}
                    >
                        <Button_1 title={"Send"} />
                    </div>
                </div>
            </form>
        </div>
    );
}

export default Form1;