import React from "react";
import configs from "../../../api";
import advantage from "../../../images/advantage.png";
import Button_1 from "../../button_home_banner/Button_1";
import { BsSquareFill } from 'react-icons/bs'
import { IoIosSquare } from 'react-icons/io'
import { GoPrimitiveDot } from 'react-icons/go'
import Image from 'next/image'
import Link from "next/link";

export default function figure_2({ title, list, src, button }) {
    return (
        <div className="container">
            <div className={src ? "figure_2_block sub" : "figure_2_block"}>
                <div className="text_block" >
                    {
                        title ?
                            <div className="figure_title">
                                <div className='figure_title_block'>
                                    <span></span>
                                    {title ? <h2>{title}</h2> : null}
                                    <span></span>
                                </div>
                            </div>
                            : null
                    }
                    <div className="figure_text">
                        <p>
                            Our staff consists of only the best specialists. Technicians at Appliance Repair Frenso are qualified and licensed. They have many years of experience in and have seen almost everything. You can call and describe what your problem is or just invite the specialist to your house for Appliance Repair in Frenso. As only the best techs work in our team your problem will be fixed in no time. Moreover, they will provide you with the best factory parts for many brands like Maytag, Viking and will also tell you how to maintain the unit in order to avoid the further breakdowns of Appliance Repair in Frenso. You can absolutely depend on their professional abilities. Call Frenso Appliance Repair service at 559 668-6976 and see it yourself.
                        </p>

                    </div>
                    {button ?
                        <div className="button_block">
                            <Button_1 title='Schedule Service' link={'/schedule-service'} />
                        </div>
                        : null}
                </div>
                <div className="photo_block">
                    {/* <Image
                        width={100}
                        height={100}
                        loader={() => src}
                        src={src || advantage}
                        alt="photo"
                        placeholder="blur"
                        blurDataURL={src || advantage}
                    /> */}
                    <img src={src || `${configs.url}/images/advantage.png`} alt="" />
                </div>
            </div>
        </div>
    );
}

