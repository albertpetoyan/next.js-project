import React from "react";
import configs from "../../../api";
import advantage from "../../../images/advantage.png";
import Button_1 from "../../button_home_banner/Button_1";
import {BsSquareFill} from 'react-icons/bs'
import {IoIosSquare} from 'react-icons/io'
import {GoPrimitiveDot} from 'react-icons/go'
import Image from 'next/image'
import Link from "next/link";

export default function Figure_3({title, list, src, button, text, line, text2}) {
    return (
        <div className="container">
            <div className={src ? "figure_3_block sub" : "figure_3_block"}>
                <div className="photo_block">
                    {/* <Image
                        width={100}
                        height={100}
                        loader={() => src}
                        src={src || advantage}
                        alt="photo"
                        placeholder="blur"
                        blurDataURL={src || advantage}
                    /> */}
                    <img src={src || `${configs.url}/images/advantage.png`} alt=""/>
                </div>
                <div className="text_block">
                    <div className="figure_title">
                        <div className='figure_title_block'>
                            {line && <span></span>}
                            {title ? <h2>{title}</h2> : null}
                            {line && <span></span>}
                        </div>
                    </div>
                    <div className="figure_text">
                        {text &&
                            <p dangerouslySetInnerHTML={{__html: text}}/>
                        }
                        <ul>
                            <li> We are only a few clicks or a phone call away</li>
                            <li> We use manufactory certified parts for repair.</li>
                            <li> We provide same day service.</li>
                        </ul>
                        {text2 &&
                            <p dangerouslySetInnerHTML={{__html: text2}}/>
                        }
                    </div>

                    {button ?
                        <div className="button_block">
                            <Button_1 title='Schedule Service' link={'/schedule-service'}/>
                        </div>
                        : null}
                </div>
            </div>
        </div>
    );
}
