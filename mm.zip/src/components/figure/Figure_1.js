import React from "react";
import configs from "../../api";
import advantage from "../../images/advantage.png";
import Button_1 from "../button_home_banner/Button_1";
import { BsSquareFill } from 'react-icons/bs'
import { IoIosSquare } from 'react-icons/io'
import { GoPrimitiveDot } from 'react-icons/go'
import Image from 'next/image'
import Link from "next/link";

export default function Figure_1({ title, list, src, button }) {
    return (
        <div className="container">
            <div className={src ? "figure_1_block sub" : "figure_1_block"}>
                <div className="photo_block">
                    {/* <Image
                        width={100}
                        height={100}
                        loader={() => src}
                        src={src || advantage}
                        alt="photo"
                        placeholder="blur"
                        blurDataURL={src || advantage}
                    /> */}
                    <img src={src || `${configs.url}/images/advantage.png`} alt="" />
                </div>
                <div className="text_block">
                    <div className="figure_title">
                        <div className='figure_title_block'>
                            <span></span>
                            {title ? <h2>{title}</h2> : null}
                            <span></span>
                        </div>
                    </div>
                    <div className="figure_text">
                        <p>
                            We are locally owned appliance repair service provider operating in the Frenso.
                            We are here to help you find the best
                            appliance repair service in your area.
                            No matter where you live, we have an experienced technician operating closer to you. So, instead of trying to handle the
                            issues yourself, just give us a call and our experienced specialists will fix them same day you call.
                        </p>
                        <h3>
                            <a href="#">
                                Call Us now!  +1 (559) 777 - 5080
                            </a>
                        </h3>

                    </div>
                    {button ?
                        <div className="button_block">
                            <Button_1 title='Schedule Service' link={'/schedule-service'} />
                        </div>
                        : null}
                </div>
            </div>
        </div>
    );
}
