import React from 'react';
import {AiOutlineClose} from 'react-icons/ai'
import { FaEnvelopeOpenText } from 'react-icons/fa';


function Popup1({setShow, icon, text, description}) {
    return (
        <>
            <div className='popup_1_bg' onClick={ev => setShow(false)}/>
            <div className="popup_1">
                <div className='popup_header'>
                    <div onClick={ev => setShow(false)}>
                        <AiOutlineClose  cursor='pointer' color='white' fontSize={25}/>
                    </div>
                </div>
                <div className='popup_content'>
                    <div className='popup_content_title'>
                        {icon}
                    </div>
                    <div className="popup_content_text">
                        <p className='popup_content_text_title'>
                            {text}
                        </p>
                        <p className='popup_content_text_description'  dangerouslySetInnerHTML={{ __html: description }}/>
                    </div>
                </div>
            </div>
        </>
    );
}

export default Popup1;