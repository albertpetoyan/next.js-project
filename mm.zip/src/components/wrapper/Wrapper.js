import React, { useEffect, useState, Suspense } from "react";
import Banner_1 from "../banner_home_2/Banner_1";
import Banner_2 from "../banner_home/Banner_2";
import HeaderMenu4 from "../header_menu/HeaderMenu4";
import Footer_2 from "../footer/footer_2/Footer_2";
import Section_1 from "../section/Section_1";
import Brands from "../brands_slider/Brands";
import { IoIosArrowUp } from "react-icons/io";
import { useRouter } from "next/router";
import Head from 'next/head'
import { routes } from "../../routs"
import NextNProgress from "nextjs-progressbar";
import NProgress from "nprogress";
import Router from "next/router";
import configs from "../../api";
import axios from "axios";

export default function Wrapper({children}) {
    NProgress.configure({
        showSpinner: false,
        easing: 'ease',
        speed: 500
    });

    const [meta, setMeta] = useState([])
    const router = useRouter()
    const page = router.asPath.replace("/", "").replaceAll("-", " ")
    const page_path = router.asPath.replace("/", "")
    const page_title = page.toUpperCase() + page.slice(1);

    useEffect(() => {
        const top_button = document.querySelector('.top-button')
        global.window.onscroll = function () {
            window.pageYOffset > 150 ? top_button.style.opacity = "1" : top_button.style.opacity = "0"
        }

        Router.onRouteChangeStart = (url) => NProgress.start();
        Router.onRouteChangeError = (url) => NProgress.done();
        Router.onRouteChangeComplete = (url) => NProgress.done();

        window.scrollTo(0, 0);
    }, [page]);

    return (
        <>
            <div className="wrapper">
                <HeaderMenu4 />
                <div id="top" className="empty_block"></div>
                {page === "home" ? <Banner_2 /> : <Banner_1 title={page} />}

                <main>
                    {children}
                </main>

                <Footer_2 />
                <div className="top-button">
                    <a href="#top">
                        <IoIosArrowUp fontSize={25} color="white" />
                    </a>
                </div>
            </div>
        </>
    );
}

