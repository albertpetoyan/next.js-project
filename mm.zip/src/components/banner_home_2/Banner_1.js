import React from "react";

export default function Banner_1({title}) {
    return (
        <div className="banner_1_block">
            <div className="container">
                <h1>{title}</h1>
            </div>
        </div>
    );
}
