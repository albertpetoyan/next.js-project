import React from 'react'

export default function List_1() {
    return (
        <div className='list_1_block'>
            <ul >
                <li>We put Safety at first place</li>
                <li>We work with experiened technicians</li>
                <li>We value your time</li>
            </ul>
            <ul >
                <li>We follow Highest Service Standards</li>
                <li>We repair at Affordable Price</li>
                <li>We repair same day you call us</li>
            </ul>
        </div>
    )
}
