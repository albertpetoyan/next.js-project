import React from "react";
import Link from "next/link";

export default function Button_1({ title, link }) {

    return (
        <Link href={link || ''} className="button_1" >
            <a className="button_1">
                <button className="btn_h first" >
                    {title}
                </button>
            </a>
        </Link>
    );
}
