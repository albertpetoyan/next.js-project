import React from "react";

export default function Section_1({ children, title }) {
    return (
        <div className="section_1">
            <div className="container">
                {
                    title ?
                        <div className='section_1_title_block'>
                            <span></span>
                            {title ? <h2>{title}</h2> : null}
                            <span></span>
                        </div>
                        : null
                }
            </div>
            <div className="section_1_content">{children}</div>
        </div>
    );
}
