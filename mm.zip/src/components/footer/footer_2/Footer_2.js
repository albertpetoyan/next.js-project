import React from "react";
import Section_1 from "../../section/Section_1";
import logo from "../../../logo/footer_logo.svg"
import { FaFacebookF, FaInstagram, FaFacebookSquare } from "react-icons/fa";
import Link from "next/link";
import Image from 'next/image'

export default function Footer_2() {
    return (
        <footer className="footer">
            <Section_1>
                <div className="container">
                    <div className="row">
                        <div className="col">
                            <Link href="/home" className="logo">
                                <a>
                                    <Image
                                        className="footer_logo_img"
                                        src={logo}
                                        alt="logo"
                                    />
                                </a>
                            </Link>
                            <p>
                                Same-day appliance repair services in Fresno.
                            </p>
                            <ul className="social">
                                <li>
                                    <a target={'_blank'} href="https://www.facebook.com">
                                        <FaFacebookSquare />
                                    </a>
                                </li>
                                <li>
                                    <a target={'_blank'} href="https://www.instagram.com">
                                        <FaInstagram />
                                    </a>
                                </li>

                            </ul>
                        </div>
                        <div className="col">
                            <h4>Sitemap</h4>
                            <ul>
                                <li>
                                    <Link href="/services">Services</Link>
                                </li>
                                <li>
                                    <Link href="/brands">Brands</Link>
                                </li>
                                <li>
                                    <Link href="/contact-us">Contact Us</Link>
                                </li>
                                <li>
                                    <Link href="/about-us">About Us</Link>
                                </li>
                            </ul>
                        </div>
                        <div className="col no">
                            <h4>Services</h4>
                            <ul>
                                <li>
                                    <Link href="/refrigerator"> Refrigerator Repair</Link>
                                </li>
                                <li>
                                    <Link href="/freezer">Freezer Repair</Link>
                                </li>
                                <li>
                                    <Link href="/washer">Washer Repair</Link>
                                </li>
                                <li>
                                    <Link href="/dryer">Dryer Repair</Link>
                                </li>
                            </ul>
                        </div>
                        <div className="col no">
                            <h4 className="title_none">&nbsp;</h4>
                            <ul>
                                <li>
                                    <Link href="/oven">Oven Repair</Link>
                                </li>
                                <li>
                                    <Link href="/stove">Stove Repair</Link>
                                </li>
                                <li>
                                    <Link href="/microwave">Microwave Repair</Link>
                                </li>
                                <li>
                                    <Link href="/range">Range Repair</Link>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </Section_1>
            <div className="#">
                <div className="copyright">
                    <p>
                        Copyright © 2022 Appliance Repair Fresno. All Rights Reserved.
                    </p>
                </div>
            </div>
        </footer>
    );
}
