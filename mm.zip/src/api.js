const configs = {
    url: "https://dappliancerepairfresno.com",
    // api:"https://server.appliancerepair-vegas.com",
    api:"http://localhost:5000",
    // db_name: "applljxg_services_fresno"
    db_name: "services_fresno"
};
export default configs;