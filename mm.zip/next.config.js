
module.exports = (phase, {defaultConfig}) => {
  return {
      async redirects() {
          return [
              {
                  source: '/',
                  destination: '/home',
                  permanent: true,
              },
          ]
      }
  }
}

